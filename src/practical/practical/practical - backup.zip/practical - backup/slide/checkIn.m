inside = checkPoint(sang, 0, spos, sdist, pad_map_lines, pad_inpolygonMapformatX, pad_inpolygonMapformatY);

if(inside)
  move_pt = spos_new;
  break;
end