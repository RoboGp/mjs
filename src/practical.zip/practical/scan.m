%---------------------------------------------------
% 20 SCANS (360deg) with a 18deg gap.
% Get the crossing points and distances along scan lines for the robot and all particles
%---------------------------------------------------

% ultraScan;
r_scan_dist_1 = ultraScan_r(sensorMot, SENSOR_2, 20, nscans);

for ind = 1:nparticles
  botpos = pos(ind, :);
  botang = ang(ind);
  ultraScan;
  scan_dist(:, ind) = distances;
  scan_dist(scan_dist > 60) = 60;
  scan_dist(scan_dist < 8) = 8;
  cross_pts(ind, :, :) = crossingPoints;
end


  



