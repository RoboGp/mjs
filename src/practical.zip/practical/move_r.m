% move the robot a certain distance
% distance: distance to move in cm
% power: the speed at which the motors turn
% forward: a boolean value that indicates whether the robot
% should move forward or backward
function move_r(leftMot, rightMot, distance, power, forward)
    power = ((forward == true) * -power + (forward ~= true) * power);
    
    % motor diameter
    motD = 4.1;
    % motor circumference/distanec per 360 turn
    motC = motD * pi;
    % convert distance to degrees
    degrees = round(360 * distance / motC);
    leftMot.TachoLimit = degrees;
    leftMot.Power = power;
    rightMot.TachoLimit = degrees;
    rightMot.Power = power;
    
    % reset the counters to 0
    leftMot.ResetPosition();
    rightMot.ResetPosition();
    leftMot.SendToNXT();
    rightMot.SendToNXT();
    leftMot.WaitFor();
    rightMot.WaitFor();
    

    % correct the angles
%     correctAng(leftMot, power, leftMot.ReadFromNXT().Position, degrees);
%     correctAng(rightMot, power, rightMot.ReadFromNXT().Position, degrees);
end

