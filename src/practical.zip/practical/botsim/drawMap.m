line(map(:,1), map(:,2), 'lineWidth', 2, 'Color', 'r'); 	% draws arena
line(new_map(:,1), new_map(:,2), 'lineWidth', 2, 'Color', 'g');