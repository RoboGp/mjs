% return a list of distances scanned at the specified angle
function USDists = localScan_r(USDists2)
USDists = USDists2;
% if(USDists(1) == 60 && (USDists(2) < 25 || USDists(end) < 25 || USDists(2) == 60 || USDists(end) == 60))
%     USDists(1) = 8;
%     USDists(2) = 8;
%     USDists(end) = 8;
% elseif (USDists(2) == 60 && (USDists(1) < 25 || USDists(end) < 25 || USDists(1) == 60 || USDists(end) == 60))
%     USDists(1) = 8;
%     USDists(2) = 8;
%     USDists(end) = 8;
% elseif (USDists(end) == 60 && (USDists(2) < 25 || USDists(1) < 25 || USDists(2) == 60 || USDists(1) == 60))
%     USDists(1) = 8;
%     USDists(2) = 8;
%     USDists(end) = 8;
% end
if(USDists(1) == 60)
    if(USDists(3) < 25)
        USDists(1) = 8;
        USDists(3) = 8;
        if(USDists(8) < 25)
            USDists(17) = 8;
        end
    elseif(USDists(17) < 25 || USDists(16) < 25)
        USDists(1) = 8;
        USDists(17) = 8;
        if(USDists(14) < 25)
            USDists(17) = 8;
        end
    elseif((USDists(3) == 60 && USDists(17) < 25) || (USDists(17) == 60 && USDists(3) < 25))
        USDists(1) = 8;
        USDists(3) = 8;
        USDists(17) = 8;
    end
elseif (USDists(3) == 60 || USDists(2) == 60 || USDists(4) == 60)
    if(USDists(1) < 25)
        USDists(1) = 8;
        USDists(3) = 8;
    elseif(USDists(8) < 25)
        USDists(3) = 8;
        USDists(8) = 8;
        %USDists(1) = 60;
    end
elseif (USDists(17) == 60  || USDists(16) == 60)
    if(USDists(3) < 25 || USDists(2) < 25 || USDists(4) < 25)
        USDists(17) = 8;
        USDists(3) = 8;
        if(USDists(14) < 25)
            USDists(17) = 8;
            USDists(14) = 8;
            %USDists(1) = 60;
        end
    elseif(USDists(1) < 25)
        USDists(1) = 8;
        USDists(17) = 8;
    end
end

% if(USDists(1) == 60 && (USDists(3) < 25 || USDists(17) < 25 || USDists(3) == 60 || USDists(17) == 60))
%     USDists(1) = 8;
%     USDists(3) = 8;
%     USDists(17) = 8;
% elseif (USDists(3) == 60 && (USDists(1) < 25 || USDists(17) < 25 || USDists(1) == 60 || USDists(17) == 60))
%     USDists(1) = 8;
%     USDists(3) = 8;
%     USDists(17) = 8;
% elseif (USDists(17) == 60 && (USDists(3) < 25 || USDists(1) < 25 || USDists(3) == 60 || USDists(1) == 60))
%     USDists(1) = 8;
%     USDists(3) = 8;
%     USDists(17) = 8;
% end

