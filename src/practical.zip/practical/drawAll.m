option = DRAW_ROBOT;
drawBot;


option = DRAW_PARTICLE;
for ind = 1:nparticles
  drawBot;
end
