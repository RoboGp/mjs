if(beyond) 
  spos = tend_pt;
  move_pt = tend_pt;
else
  sdist = 0;
  move_pt = proj_pt;
end

