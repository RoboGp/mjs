clc
close all
simulation